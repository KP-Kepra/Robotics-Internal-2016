#include "stm32f10x.h"
#include "ticks.h"
#include "delay.h"

void ultrasonic_init();
float ultrasonic_emit();

int ultrasonic_check();