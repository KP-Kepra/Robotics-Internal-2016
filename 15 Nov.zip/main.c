#include "main.h"

#define led_port GPIOA
#define LED_L  GPIO_Pin_4
#define LED_M  GPIO_Pin_3
#define LED_R  GPIO_Pin_15
/*
void manual_mode(const u8 byte) { //Manual Mode Function
	static int t = 0; //Trigger for manual mode
	if ((byte == ' ') && (t == 0)) {
		uart_tx(COM3, "Switched to manual mode\n");
		t = 1;
	}
		
	if (t == 1) {
		switch(byte) {
			case 'W' :
			case 'w'	:
				uart_tx(COM3, "Move forward\n");
				move_forward(75);
				break;
			
			case 'A'	:
			case 'a'	:
				uart_tx(COM3, "Turn left\n");
				turn_left_atplace(75);
				break;
			
			case 'S'	:
			case 's'	:
				uart_tx(COM3, "Move backward\n");
				move_backward(75);
				break;
			
			case 'D' :
			case 'd'	:
				uart_tx(COM3, "Move right\n");
				turn_right_atplace(75);
				break;
			
			case 'J'	:
			case 'j'	:
				uart_tx(COM3, "Shoot\n");
				int pneu_ticks = get_real_ticks(); 
				while (get_real_ticks() - pneu_ticks <= 1000) { //Hold the valve open for 1 second
					pneumatic_control(PNEUMATIC3, 1);
				}
					pneumatic_control(PNEUMATIC3, 0);
				break;
				
			case 'O'	:
			case 'o'	:
				uart_tx(COM3, "Grab basket");
				pneumatic_control(PNEUMATIC1, 1);
				pneumatic_control(PNEUMATIC1, 0);
				break;
			
			default :
				motor_stop();
				break;
			/*
			case 'I'	:
			case 'i'	:
				uart_tx(COM3, "Raise grabber up");
				int grab_tick = get_real_ticks();
				if ((get_real_ticks() - c >= 100) && (pos < 1050)){	
					c = get_real_ticks();
				}
					
				pos = (pos < 1050 ? (pos+1) : 1050);
				servo_control(0, pos);
				break;
				
			case 'K'	: 
			case 'k'	: 
				uart_tx(COM3, "Raise grabber down");
				int degrab_tick = get_real_ticks();
				if ((get_real_ticks() - degrab_tick >= 100) && (pos < 1050)){	
					c = get_real_ticks();
				}
						
				pos = (pos > 450 ? (pos-1) : 450);
				servo_control(0, pos);
				break;*/
	/*	}
	}
}*/
	
int main() {
	/** INITIALIZATION */
	//uart_init(COM3, 115200);
	//uart_interrupt_init(COM3, &manual_mode);
	//tft_init(2, BLACK, WHITE);
	//adc_init();
	//led_init();
	//button_init();
	//linear_ccd_init();
	ultrasonic_init();
	IR_init();
	gpio_init();
	//servo_init(143, 10000, 750); //Value for smartcar
	//motor_init(71, 180, 50); //Value for smartcar
	motor_init(71, 100, 0);// Value for shooter robot 
	pneumatic_init();
	ticks_init();
	
	//motor_control(MOTOR1, 1, 100);
	//motor_control(MOTOR2, 0, 0);

	while (1) {
		/** ULTRASONIC TEST */
		/*
		if (get_real_ticks() % 500 == 0) {			
			float distance = ultrasonic_emit();
			tft_clear();
			tft_prints(0,0,"%.2f", distance);
		}
		*/
		
		/** INFRARED TEST */
		/*
		if (get_real_ticks() % 500 == 0) {
			int output = read_IR(0);
			tft_clear();
			tft_prints(0, 0, "%d", output);
		}*/
		
		/** USE OF STATES */
		/*switch(state) {
			case 1 : state1_move(); break;
			case 2 : state2_move(); break;
			case 3 : state3_move(); break;
			case 4 : state4_move(); break;
			case 5 : state5_move(); break;
			case 6 : state6_move(); break;
		}*/
	
	/**	LINEAR CCD */
	//ideone.com/CZsOXN		
	/*
		if (get_real_ticks() % 10 == 0) { //Every 10 miliseconds
			for (int red = 0; red < 128; red++) {
				tft_put_pixel(red, 40, RED);
			}
			
			for (int n = 0; n < 128; n++) {
				tft_put_pixel(n, 160-dest_array[n]+11, BLACK);
			}
			linear_ccd_read();
			for (int n = 0; n < 128; n++) {
				tft_put_pixel(n, 160-dest_array[n]+11, WHITE);
			}
			
			int right_counter = 0;
			int left_counter =0;
			for (int index = 0; index < 48; index++) {
				if (160-dest_array[index+80]+11 >= 40) {
					tft_put_pixel(index+80, 60, GREEN);
					right_counter++;
				}
				else {
					tft_put_pixel(index+80, 60, BLACK);
				}
				
				if (160-dest_array[index]+11 >= 40) {
					tft_put_pixel(index, 60, BLUE);
					left_counter++;
				}
				else {
					tft_put_pixel(index, 60, BLACK);
				}
			}
		
			if (right_counter-left_counter >= 10) {
				servo_control(SERVO1, 750 + (right_counter - left_counter)*2);
				motor_control(MOTOR1, 0, 10);
			}
			else if (left_counter - right_counter >= 10) {
				servo_control(SERVO1, 750 + (right_counter - left_counter)*2);
				motor_control(MOTOR1, 0, 10);
			}
			else {
				servo_control(SERVO1, 750);
				motor_control(MOTOR1, 1, 50); 
			}
		}
	}
}*/

	/** Shooter robot  testing*/
		if (ticks_img != get_real_ticks()){
			ticks_img=get_real_ticks();
			//Do update every 200ms
			if (ticks_img%200 ==0){
				distance = ultrasonic_emit();
				//stage moving 
				switch(state) {
					case 1 : state1_move(); break;
					case 2 : state2_move(); break;
					case 3 : state3_move(); break;
					case 4 : state4_move(); break;
					case 5 : state5_move(); break;
					case 6 : state6_move(); break;
					//case 7 : state7_move(); break;
			}
		}
		}
	}
