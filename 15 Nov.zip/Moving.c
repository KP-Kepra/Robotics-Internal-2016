#include "Moving.h"

/*
 * Remember to initial IR at the main function
 * Moving from stage 1 to stage2
 * (Including picking up the basket)
 * Add ticks.c if necessary
 */

/*
 * For our shooter robot:
 * Pin_B6 is for #left# IR sensor
 * Pin_B7 is for #right# IR sensor
 * MOTOR1 is for #left# motor
 * MOTOR2 is for #right# motor
 * Dir 1 is forward
 * Dir 0 is backward
 * 1 is for white line
 * 0 is for black line
 * PNEUMATIC1 : grabber claw
 * PNEUMATIC2 : grabber lift
 */
 
static int state = 1;
float distance = 0;
int ir_left;
int ir_right;

int tright_state3 = 0;
int tright_state5 = 0;
u32 ticks_img;

/* State 1
	* Action : move forward
	* Stops : when ultrasonic detects basket at less than x cm
	*/
void state1_move(void){
	if (distance>=10){
	 move_forward(50);
	}
	if (distance<10){
		motor_stop();
		state=2;
	}
}

/* State 2
	* Action : Grab, lift basket
	* Stops : when ultrasonic doesn't detect basket at most x cm
	*/
void state2_move(void) {
	if (distance < 10) { 
		_delay_ms(1000);
		pneumatic_control(PNEUMATIC1, 1);
		_delay_ms(1000);
		pneumatic_control(PNEUMATIC2, 1);
		state=3; 
	}
}

/* State 3
	* Action : Turn right, move forward
	* Stops : when ultrasonic detects wall at less than x cm
	*/
void state3_move(void) {
	if (tright_state3 == 0) {
		u32 tright_time = ticks_img;
		// turn for 1 second
		while (ticks_img - tright_time <= 1000) {
			turn_right_half(50);
		}
		tright_state3 = 1;
	}
 // move forward	
	move_forward(50);
	if (distance <= 10) {
		motor_stop();
		_delay_ms(1000);
		state=4; 
	}
}

/* State 4
	* Action : drops basket, move backwards, delift grabber
	* Stops : nothing
	*/
void state4_move(void) {
	pneumatic_control(PNEUMATIC1, 0);
	int mback_state4 = 0;
	if (mback_state4 == 0){
		u32 mback_time = ticks_img;
		while (ticks_img - mback_time <= 1000) {
			move_backward(50);
		}
		mback_state4 =1;
	}
	pneumatic_control(PNEUMATIC2, 0);
	state=5;
}

/* State 5
	* Action : turn right, move forward until left IR sensor detects nothing
	* Stops : left IR sensor detects nothing
	*/
void state5_move(void) {
	
	/*// turn right atplace 90 degree first
	if(tright_state5 == 0) {		
		while (get_real_ticks()- ticks_img <= 1000) {
			turn_right_atplace(50);
		}
		tright_state5 =1;
	}
	// move forward until horizontal white line
	if(tright_state5==1) {move_forward(50);}
	ir_left = read_IR(0);
	ir_right = read_IR(1);

	// turn left half 90 degree 
	if (ir_left == 1 && ir_right == 1){
			while (get_real_ticks() - ticks_img <= 1000) {
				turn_left_half(50);
			}
		}
	//Use ultrasonic to decide if it can move to the next stage
	if(distance >10) {state=6;}
	//
	else{  
		while (get_real_ticks() - ticks_img <= 1000) {
			turn_right_half(50);}
	}*/
}

/* State 6
	* Action : move forward, until right sensor detects smart car
	* Stops : right sensor detects smart car
	*/
void state6_move(void) {
	/*
	move_forward(50);
	if (get_real_ticks() % 500 == 0) {
		ir_left = read_IR(0);
		ir_right = read_IR(1);
	}
		if (ir_left == 0 && ir_right == 0) {
			u32 t180_time = get_real_ticks();
			while (get_real_ticks() - t180_time <= 4000) {
				turn_right_atplace(50);
			}
			state =7;
		}*/
}

/* State 7
	* Action : Turn 180 and shoot the ball
	* Stops : Nothing
	*/