#include "gpio.h"

void IR_init(void);
int read_IR(int pos);
