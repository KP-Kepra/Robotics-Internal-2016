#include "main.h"

#define led_port GPIOA
#define LED_L  GPIO_Pin_4
#define LED_M  GPIO_Pin_3
#define LED_R  GPIO_Pin_15
#define BUTTON2 2

  void manual_mode(const u8 byte) { //Manual Mode Function
		static int t = 0; //Trigger for manual mode
		if ((byte == ' ') && (t == 0)) {
			t = 1;
		}
		
	  if (t == 1) {
			if ((byte == 'W')||(byte == 'w')) {
			 //uart_tx(COM3, "Move Forward");
			 //Move forward
			 /* right motor turns counter clockwise
				 * left motor turns clockwise
				 * motor_control(ID1, 0, 100);
				 * motor_control(ID2, 1, 100);
				 */
			}
		
			if ((byte == 'A') || (byte == 'a')) {
				//Turn left
				/* right motor turns counter clockwise
					* left motor turns counter clockwise
					* motor_control(ID1, 0, 100);
					* motor_control(ID2, 0, 100);
					*/
			}
		 
			if ((byte == 'S') || (byte == 's')) {
				//Move backward
				/*right motor turns clockwise
						left motor turns counter clockwise
						motor_control(ID1, 1, 100);
						motor_control(ID2, 0, 100);
					*
				//Stop the wheels
						right motor stops
						left motor stops
						motor_control(ID1, 0, 0);
						motor_control(ID2, 0, 0);
					*/
			}
		 
			if ((byte == 'D') || (byte == 'd')) {
				//Turn right
				/*right motor turns clockwise
					 left motor turns clockwise
					 motor_control(ID1, 1, 100);
					 motor_control(ID2, 1, 100);
					*/
			}
			
			if ((byte == 'J') || (byte == 'j')) { //Shoot
				//Turn on pneumatic function
				/*	
						int pneu_ticks = get_real_ticks(); 
						while (get_real_ticks() - pneu_ticks <= 1000) { //Hold the valve open for 1 second
							pneumatic_control(id, 1);
						}
							pneumatic_control(id, 0);
					*/
			}
			
			if ((byte == 'I') || (byte == 'i')) {
				//Raise the grabber up
				/*int grab_tick = get_real_ticks();
						if ((get_real_ticks() - c >= 100) && (pos < 1050)){	
						c = get_real_ticks();
						}
					
						pos = (pos < 1050 ? (pos+1) : 1050);
						servo_control(0, pos);
					*/
			}
			
			if ((byte == 'K') || (byte == 'k')) {
				//Pull the grabber down
				/*int grab_tick = get_real_ticks();
						if ((get_real_ticks() - c >= 100) && (pos < 1050)){	
							c = get_real_ticks();
						}
						
						pos = (pos > 450 ? (pos-1) : 450);
						servo_control(0, pos);
					*/
			}
		}
}
	
int main() {
	/** INITIALIZATION */
	//uart_init(COM3, 115200);
	//uart_interrupt_init(COM3, &manual_mode);
	tft_init(2, BLACK, WHITE);
	
	adc_init();

	//led_init();
	//button_init();
	
	linear_ccd_init();
	ultrasonic_init();
	//infrared_init();
	//gpio_init();
	
	servo_init(143, 10000, 750);
	//motor_init(143, 10000, 750);
	//pneumatic_init();

	ticks_init();
	
	//static state = 0; //State initialization
	int ccd_ticks = 0;
	
	while (1) {
		/** ULTRASONIC TEST */
		/*
		if (get_real_ticks() % 500 == 0) {			
			float distance = ultrasonic_emit();
			tft_clear();
			tft_prints(0,0,"%.2f", distance);
		}*/
		
		/** USE OF STATES */
		/*while (state == 0) {
			if (condition) {
				state++;
				break;
			}
		}
		
		while (state == 1) {
			if (condition) {
				state++;
				break;
			}
		}
		
		while (state == 2) {
			if (condition) {
				state++;
				break;
			}
		}
		
		while (state == 3) {
			if (condition) {
				state++;
				break;
			}
		}
		*/
		
	/**	DATA FILTERING */
	/*
	u32 raw_array[128];
	u32 result_array[128];
	
	for (int a = 0; a < 128; a++) { //Random integers
		raw_array[a] = rand() % 100 + 1;
	}
	
		while (read_button(BUTTON2) == 0) { //Erase the while loop in final code
			savgol_filter(raw_array, result_array, 5);
		}			
		tft_clear();
		while (read_button(BUTTON2) == 1) {
			for (int a = 0; a < 128; a++) {
				tft_put_pixel(a, raw_array[a], WHITE);
			}
		}
		tft_clear();
	*/
		
	/**	PNEUMATIC VALVE */
	/*
		pneumatic_control(id, 1);
		pneumatic_control(id, 0);
	*/
	
	/**	INFRA RED SENSOR */
	/*
																																																																																																																											
	*/
	
	/**	LINEAR CCD */
	
		if (get_real_ticks() % 10 == 0) { //Every 10 miliseconds
			for (int red = 0; red < 128; red++) {
				tft_put_pixel(red, 40, RED);
			}
			
			for (int n = 0; n < 128; n++) {
				tft_put_pixel(n, 160-dest_array[n]+11, BLACK);
			}
			linear_ccd_read();
			for (int n = 0; n < 128; n++) {
				tft_put_pixel(n, 160-dest_array[n]+11, WHITE);
			}
			
			int right_counter = 0;
			for (int green = 79; green < 128; green++) {
				if (160-dest_array[green]+11 >= 40) {
					tft_put_pixel(green, 60, GREEN);
					right_counter++;
				}
				else {
					tft_put_pixel(green, 60, BLACK);
				}
			}
		
			/*if (right_counter >= 30) {
				servo_control(SERVO1, 800);
			}
			els e {
				servo_control(SERVO1, 750);
			}*/
		}
		
	}
}